/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AbstractFactory;

/**
 *
 * @author taha
 */
public interface AbstractSuniFactory {
    ISuniDeri Sunideriyap(String renk,int id,int istenen_miktar,int gun);
}
