/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package nesneproje;


public interface Mali {
    int gelir(int tc);
    int gider(int tc);
    int kar_zarar(int tc);
    void MaliVeriEkleme(int gun);
}
